﻿namespace AdapterDemoBefore;

public class LejemaalListAdapter : ILejemaalListTarget
{
    /// <summary>
    /// TODO: Implementer denne metode
    /// </summary>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    List<Lejemaal> ILejemaalListTarget.HentLejemaal()
    {
        throw new NotImplementedException();
    }
}